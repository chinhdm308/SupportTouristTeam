package dmc.supporttouristteam.data.model;

public class Result {
    public String message_id;
}
