package dmc.supporttouristteam.presenter.love_places;

public interface LovePlacesContract {
    interface View {
        void showLovePlaceDetail(int pos);
    }
}
